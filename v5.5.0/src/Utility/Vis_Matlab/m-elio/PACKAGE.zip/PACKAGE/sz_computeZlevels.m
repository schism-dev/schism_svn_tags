function [z] = sz_computeZlevels(dp, eta, vgrid)
%[zLevels] = sz_computeZlevels(dp, eta, vgrid)
% convert sigma-z coordinates to Z levels
% dp 	- depth 	[np,1]
% eta 	- elevation	[np,1]
%	np is number of points, 
%	points don't need to coinside with points of the horizontal grid
% vgrid - vertical grid structurte (e.g. as returned in sb_header)
% zLevel- [np,nLevs] Z level at each  
%	zLevs(:,1)=dp, zLevs(:,end)=eta
%
% NOTE: there may be a suttle difference in the output of these function 
%	and zLevels in ?_zcor.63. 
%	for dry nodes ?_zcor.63 has zLevs=0, I have zLevs=dp
%	hence you can find later almost all dry nodes as idx=find(zLevs(:,end)==dp)
%
% Sergey Frolov May 2005

%1) compute sigma levels reusing code for pure sigma levles
%   includes faking dp=vgrid.hs if dp>hs
[zs] = sb_computeZlevels(min(vgrid.hs,dp), eta, vgrid);


%2) concatinate arrays for sigma and z levels
zz = repmat(vgrid.zLevels',size(zs,1),1);

z=[zs zz];
